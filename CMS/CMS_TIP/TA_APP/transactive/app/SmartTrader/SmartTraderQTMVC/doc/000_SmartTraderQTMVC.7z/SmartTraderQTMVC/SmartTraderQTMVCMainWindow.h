#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QModelIndex>

#include "ui_SmartTraderQTMVC.h"

class QAction;
class QTreeView;
class QWidget;

class SmartTraderQTMVCMainWindow : public QMainWindow, private Ui::MainWindow
{
    Q_OBJECT

public:
    SmartTraderQTMVCMainWindow(QWidget *parent = 0);

public slots:
    void updateActions();

private slots:
    void insertChild();
    bool insertColumn(const QModelIndex &parent = QModelIndex());
    void insertRow();
    bool removeColumn(const QModelIndex &parent = QModelIndex());
    void removeRow();
};

#endif
