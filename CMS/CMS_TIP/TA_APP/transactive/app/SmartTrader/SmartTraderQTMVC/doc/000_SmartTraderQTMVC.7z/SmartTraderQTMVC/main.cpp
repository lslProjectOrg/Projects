#include <QtGui>

#include "SmartTraderQTMVCMainWindow.h"

int main(int argc, char *argv[])
{
    Q_INIT_RESOURCE(SmartTraderQTMVC);

    QApplication app(argc, argv);
    SmartTraderQTMVCMainWindow window;
#if defined(Q_OS_SYMBIAN)
    window.showMaximized();
#else
    window.show();
#endif
    return app.exec();
}
