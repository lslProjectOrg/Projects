//#include "vld.h"




#include "sqlgen.h"

int main()
{
	sqlgen *pSqlFileHelper = new sqlgen();

	delete pSqlFileHelper;
	pSqlFileHelper = NULL;
	return 0;
}










